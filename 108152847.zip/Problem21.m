%home work 2
