package java.io;

public class FileNotFoundException extends IOException {

    public FileNotFoundException() {
        super();
    }
    
    public FileNotFoundException(String s) {
        super(s);
    }
}
