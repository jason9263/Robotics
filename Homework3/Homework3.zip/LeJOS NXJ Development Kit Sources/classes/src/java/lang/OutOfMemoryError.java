package java.lang;

public class OutOfMemoryError extends Error
{
	public OutOfMemoryError()
	{
		super();
	}

	public OutOfMemoryError(String message)
	{
		super(message);
	}	
}
