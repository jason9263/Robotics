package java.lang;

public class VirtualMachineError extends Error
{
	public VirtualMachineError()
	{
		super();
	}

	public VirtualMachineError(String message)
	{
		super(message);
	}
}
