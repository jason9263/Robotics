package lejos.nxt;

/**
 * Interface for calling calling lejos listeners.
 */
public interface ListenerCaller {
  int callListeners();
}

