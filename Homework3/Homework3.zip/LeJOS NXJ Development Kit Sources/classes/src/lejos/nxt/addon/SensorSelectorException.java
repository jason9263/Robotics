package lejos.nxt.addon;

/*
 * WARNING: THIS CLASS IS SHARED BETWEEN THE classes AND pccomms PROJECTS.
 * DO NOT EDIT THE VERSION IN pccomms AS IT WILL BE OVERWRITTEN WHEN THE PROJECT IS BUILT.
 */

public class SensorSelectorException extends Exception {

	public SensorSelectorException(String message) {
		super(message);
	}

}
