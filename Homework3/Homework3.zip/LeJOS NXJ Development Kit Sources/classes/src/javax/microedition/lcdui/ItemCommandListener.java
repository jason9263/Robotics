package javax.microedition.lcdui;

/**
 * 
 * @author Andre Nijholt
 */
public interface ItemCommandListener {
	public void commandAction(Command c, Item d);
}
