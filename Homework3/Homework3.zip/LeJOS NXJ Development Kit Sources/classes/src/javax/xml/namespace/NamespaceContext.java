package javax.xml.namespace;

public class NamespaceContext {

}
